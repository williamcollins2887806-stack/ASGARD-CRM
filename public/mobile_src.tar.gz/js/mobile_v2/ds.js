/**
 * ASGARD CRM — Mobile Design System v2.0
 * Токены, типографика, анимации, темы
 * Референс: finance_v3.jsx (Alfa-Bank × Ozon × Norse)
 */

const DS = (() => {
  /* ──────────────── ЦВЕТОВЫЕ ТЕМЫ ──────────────── */
  const themes = {
    light: {
      name: 'light',
      bg: '#F2F3F5',
      surface: '#FFFFFF',
      surfaceAlt: '#F7F7FA',
      text: '#1A1A1F',
      textSec: '#6E6E78',
      textTer: '#A8A8B2',
      border: 'rgba(0,0,0,0.06)',
      borderStrong: 'rgba(0,0,0,0.12)',

      // Brand
      red: '#C62828',
      redBright: '#E53935',
      redBg: 'rgba(198,40,40,0.08)',
      redBorder: 'rgba(198,40,40,0.15)',
      blue: '#1E5A99',
      blueBright: '#2B7BD4',
      blueBg: 'rgba(30,90,153,0.08)',
      blueBorder: 'rgba(30,90,153,0.15)',
      gold: '#C49A2A',
      goldBg: 'rgba(196,154,42,0.08)',
      goldBorder: 'rgba(196,154,42,0.15)',
      green: '#1A9F4A',
      greenBg: 'rgba(26,159,74,0.08)',
      greenBorder: 'rgba(26,159,74,0.15)',
      orange: '#E65100',
      orangeBg: 'rgba(230,81,0,0.08)',
      orangeBorder: 'rgba(230,81,0,0.15)',

      // Gradients
      heroGrad: 'linear-gradient(135deg, #C62828 0%, #8B1A1A 22%, #4A1942 45%, #1565C0 75%, #0A5DC2 100%)',
      heroGradSoft: 'linear-gradient(145deg, rgba(10,93,194,0.12) 0%, rgba(198,40,40,0.12) 100%)',
      shimmerGrad: 'linear-gradient(90deg, #F7F7FA 25%, #EDEDF0 50%, #F7F7FA 75%)',

      // Tab bar
      tabBarBg: 'rgba(255,255,255,0.94)',

      // Shadows
      shadow: '0 2px 12px rgba(0,0,0,0.05)',
      shadowHover: '0 8px 24px rgba(0,0,0,0.1)',
      heroShadow: '0 8px 32px rgba(198,40,40,0.2)',
      fabShadow: '0 4px 20px rgba(198,40,40,0.35)',

      // Misc
      inputBg: '#F7F7FA',
      overlay: 'rgba(0,0,0,0.4)',
      selection: 'rgba(30,90,153,0.15)',
    },
    dark: {
      name: 'dark',
      bg: '#0D0D0F',
      surface: '#1A1A1F',
      surfaceAlt: '#222228',
      text: '#F5F5F7',
      textSec: '#8E8E93',
      textTer: '#4A4A50',
      border: 'rgba(255,255,255,0.06)',
      borderStrong: 'rgba(255,255,255,0.12)',

      // Brand
      red: '#E53935',
      redBright: '#FF5252',
      redBg: 'rgba(229,57,53,0.12)',
      redBorder: 'rgba(229,57,53,0.2)',
      blue: '#4A90D9',
      blueBright: '#64B5F6',
      blueBg: 'rgba(74,144,217,0.12)',
      blueBorder: 'rgba(74,144,217,0.2)',
      gold: '#D4A843',
      goldBg: 'rgba(212,168,67,0.12)',
      goldBorder: 'rgba(212,168,67,0.2)',
      green: '#34C759',
      greenBg: 'rgba(52,199,89,0.12)',
      greenBorder: 'rgba(52,199,89,0.2)',
      orange: '#FF9500',
      orangeBg: 'rgba(255,149,0,0.12)',
      orangeBorder: 'rgba(255,149,0,0.2)',

      // Gradients
      heroGrad: 'linear-gradient(135deg, #C62828 0%, #6B1515 22%, #3A1535 45%, #1E5A99 75%, #1A4A8A 100%)',
      heroGradSoft: 'linear-gradient(145deg, rgba(26,74,138,0.15) 0%, rgba(198,40,40,0.15) 100%)',
      shimmerGrad: 'linear-gradient(90deg, #222228 25%, #2A2A32 50%, #222228 75%)',

      // Tab bar
      tabBarBg: 'rgba(26,26,31,0.94)',

      // Shadows
      shadow: '0 2px 12px rgba(0,0,0,0.3)',
      shadowHover: '0 8px 24px rgba(0,0,0,0.4)',
      heroShadow: '0 8px 32px rgba(198,40,40,0.3)',
      fabShadow: '0 4px 20px rgba(198,40,40,0.5)',

      // Misc
      inputBg: '#222228',
      overlay: 'rgba(0,0,0,0.6)',
      selection: 'rgba(74,144,217,0.2)',
    }
  };

  /* ──────────────── ТИПОГРАФИКА ──────────────── */
  const typography = {
    xs:    { size: '10px', weight: 500, lineHeight: 1.3 },
    sm:    { size: '12px', weight: 400, lineHeight: 1.4 },
    base:  { size: '14px', weight: 400, lineHeight: 1.5 },
    md:    { size: '16px', weight: 600, lineHeight: 1.3 },
    lg:    { size: '20px', weight: 700, lineHeight: 1.2, letterSpacing: '-0.4px' },
    xl:    { size: '24px', weight: 800, lineHeight: 1.1, letterSpacing: '-0.6px' },
    hero:  { size: '30px', weight: 800, lineHeight: 1.0, letterSpacing: '-1px' },
    label: { size: '10px', weight: 500, lineHeight: 1.3, letterSpacing: '1px', textTransform: 'uppercase' },
  };

  /* ──────────────── ОТСТУПЫ И СКРУГЛЕНИЯ ──────────────── */
  const spacing = {
    xxs: 4,  xs: 8,  sm: 12,  md: 14,  base: 16,  lg: 20,  xl: 24,  xxl: 32,
    page: 20,  // padding по бокам страницы
    gap: 12,   // gap между карточками
  };

  const radius = {
    xs: 4, sm: 8, md: 12, lg: 14, xl: 18, xxl: 20, hero: 20, pill: 44,
  };

  /* ──────────────── ТЕКУЩАЯ ТЕМА ──────────────── */
  let currentTheme = 'dark';
  let t = themes.dark;

  function setTheme(name) {
    if (!themes[name]) return;
    currentTheme = name;
    t = themes[name];

    // Inject CSS variables
    const root = document.documentElement;
    for (const [key, value] of Object.entries(t)) {
      root.style.setProperty('--' + camelToDash(key), value);
    }

    // Typography variables
    for (const [key, val] of Object.entries(typography)) {
      root.style.setProperty(`--font-${key}-size`, val.size);
      root.style.setProperty(`--font-${key}-weight`, String(val.weight));
      root.style.setProperty(`--font-${key}-lh`, String(val.lineHeight));
      if (val.letterSpacing) root.style.setProperty(`--font-${key}-ls`, val.letterSpacing);
    }

    // Spacing variables
    for (const [key, val] of Object.entries(spacing)) {
      root.style.setProperty(`--sp-${key}`, val + 'px');
    }

    // Radius variables
    for (const [key, val] of Object.entries(radius)) {
      root.style.setProperty(`--r-${key}`, val + 'px');
    }

    // Meta theme-color
    let metaTheme = document.querySelector('meta[name="theme-color"]');
    if (!metaTheme) {
      metaTheme = document.createElement('meta');
      metaTheme.name = 'theme-color';
      document.head.appendChild(metaTheme);
    }
    metaTheme.content = t.bg;

    // Body transition
    document.body.style.transition = 'background-color 0.4s ease, color 0.4s ease';
    document.body.style.backgroundColor = t.bg;
    document.body.style.color = t.text;

    // Store
    if (typeof Store !== 'undefined') Store.set('theme', name);
    try { localStorage.setItem('asgard_theme', name); } catch (_) {}

    // Dispatch event
    window.dispatchEvent(new CustomEvent('asgard:theme', { detail: { theme: name } }));
  }

  function toggleTheme() {
    setTheme(currentTheme === 'dark' ? 'light' : 'dark');
  }

  function getTheme() {
    return currentTheme;
  }

  /* ──────────────── CSS INJECTION ──────────────── */
  function injectStyles() {
    if (document.getElementById('asgard-ds-styles')) return;

    const style = document.createElement('style');
    style.id = 'asgard-ds-styles';
    style.textContent = generateCSS();
    document.head.appendChild(style);

    // Load saved theme or default to dark
    const saved = localStorage.getItem('asgard_theme');
    setTheme(saved || 'dark');
  }

  function generateCSS() {
    return `
/* ═══════════════════════════════════════════
   ASGARD CRM Mobile — Design System CSS
   ═══════════════════════════════════════════ */

/* Font family */
*, *::before, *::after {
  box-sizing: border-box;
  -webkit-tap-highlight-color: transparent;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

html {
  font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Text', 'SF Pro Display', system-ui, sans-serif;
  font-size: 14px;
  line-height: 1.5;
  overscroll-behavior: none;
  -webkit-text-size-adjust: 100%;
}

body {
  margin: 0;
  padding: 0;
  overflow: hidden;
  position: fixed;
  width: 100%;
  height: 100%;
  background-color: var(--bg);
  color: var(--text);
}

/* ───── Scrollbar hiding ───── */
.asgard-no-scrollbar::-webkit-scrollbar { display: none; }
.asgard-no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }

/* ═══════ SHELL LAYOUT ═══════ */
.asgard-shell {
  display: flex;
  flex-direction: column;
  height: 100vh;
  height: 100dvh;
  position: relative;
  overflow: hidden;
}

.asgard-content {
  flex: 1;
  overflow-y: auto;
  overflow-x: hidden;
  -webkit-overflow-scrolling: touch;
  overscroll-behavior-y: contain;
  position: relative;
  padding-top: env(safe-area-inset-top);
}

/* ═══════ PAGE TRANSITIONS ═══════ */
.asgard-page {
  min-height: 100%;
  padding-bottom: 100px;
  will-change: transform, opacity;
}

.asgard-slide-left {
  animation: asgardSlideLeft 0.35s cubic-bezier(.34,1.56,.64,1) forwards;
}
.asgard-slide-right {
  animation: asgardSlideRight 0.35s cubic-bezier(.34,1.56,.64,1) forwards;
}
.asgard-fade {
  animation: asgardFade 0.25s ease forwards;
}
.asgard-page-exit {
  animation: asgardPageExit 0.3s ease forwards;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
}

/* ═══════ TAB BAR ═══════ */
.asgard-tabbar {
  display: flex;
  align-items: flex-end;
  justify-content: space-around;
  background: var(--tab-bar-bg);
  backdrop-filter: blur(24px);
  -webkit-backdrop-filter: blur(24px);
  border-top: 1px solid var(--border);
  padding: 6px 0;
  padding-bottom: calc(6px + env(safe-area-inset-bottom));
  position: relative;
  z-index: 100;
  flex-shrink: 0;
}

.asgard-tabbar__item {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 2px;
  padding: 4px 0;
  min-width: 56px;
  text-decoration: none;
  color: var(--text-ter);
  position: relative;
  transition: color 0.2s ease;
}

.asgard-tabbar__item.active {
  color: var(--text);
}

.asgard-tabbar__icon {
  width: 22px;
  height: 22px;
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0.35;
  transition: opacity 0.2s ease, filter 0.2s ease;
}
.asgard-tabbar__icon svg {
  width: 22px;
  height: 22px;
}

.asgard-tabbar__item.active .asgard-tabbar__icon {
  opacity: 1;
  filter: none;
}

.asgard-tabbar__label {
  font-size: 10px;
  font-weight: 500;
  line-height: 1;
}

.asgard-tabbar__indicator {
  width: 4px;
  height: 4px;
  border-radius: 50%;
  background: transparent;
  margin-top: 2px;
  transition: background 0.2s ease;
}

.asgard-tabbar__item.active .asgard-tabbar__indicator {
  background: var(--red);
}

.asgard-tabbar__badge {
  position: absolute;
  top: 0;
  right: 8px;
  min-width: 16px;
  height: 16px;
  border-radius: 8px;
  background: var(--red);
  color: #fff;
  font-size: 9px;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0 4px;
}

/* ═══════ FAB (Mimir) ═══════ */
.asgard-tabbar__fab {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background: var(--hero-grad);
  border: none;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: -22px;
  box-shadow: var(--fab-shadow);
  position: relative;
  z-index: 2;
  cursor: pointer;
  animation: asgardFabPulse 3s infinite;
  transition: transform 0.2s ease;
}
.asgard-tabbar__fab:active {
  transform: scale(0.92);
}
.asgard-tabbar__fab svg {
  width: 24px;
  height: 24px;
  filter: drop-shadow(0 1px 2px rgba(0,0,0,0.3));
  stroke-width: 2.5;
}

/* ═══════ PULL TO REFRESH ═══════ */
.asgard-ptr {
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  transition: height 0.3s ease;
}
.asgard-ptr__spinner {
  width: 24px;
  height: 24px;
  border: 2px solid var(--border);
  border-top-color: var(--red);
  border-radius: 50%;
  transition: transform 0.1s linear;
}
.asgard-ptr--refreshing .asgard-ptr__spinner {
  animation: asgardSpin 0.8s linear infinite;
}

/* ═══════ SWIPE ACTIONS ═══════ */
.asgard-swipe-inner {
  position: relative;
  z-index: 1;
  background: var(--surface);
  will-change: transform;
}
.asgard-swipe-actions {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  display: flex;
  z-index: 0;
}
.asgard-swipe-action {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 72px;
  border: none;
  color: #fff;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
}

/* ═══════ OVERLAY ═══════ */
.asgard-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 1000;
  pointer-events: none;
}
.asgard-overlay > * {
  pointer-events: auto;
}

/* ═══════ KEYFRAMES ═══════ */
@keyframes asgardSlideLeft {
  from { transform: translateX(100%); opacity: 0.8; }
  to { transform: translateX(0); opacity: 1; }
}

@keyframes asgardSlideRight {
  from { transform: translateX(-30%); opacity: 0.8; }
  to { transform: translateX(0); opacity: 1; }
}

@keyframes asgardFade {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes asgardPageExit {
  from { opacity: 1; transform: translateX(0); }
  to { opacity: 0; transform: translateX(-20%); }
}

@keyframes asgardSlideUp {
  from { transform: translateY(14px); opacity: 0; }
  to { transform: translateY(0); opacity: 1; }
}

@keyframes asgardPopUp {
  from { transform: translateY(4px) scale(0.96); opacity: 0; }
  to { transform: translateY(0) scale(1); opacity: 1; }
}

@keyframes asgardFadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes asgardShimmer {
  0% { background-position: 200% 0; }
  100% { background-position: -200% 0; }
}

@keyframes asgardSpin {
  to { transform: rotate(360deg); }
}

@keyframes asgardFabPulse {
  0%, 100% { box-shadow: var(--fab-shadow); }
  50% { box-shadow: 0 4px 28px rgba(198,40,40,0.55); }
}

@keyframes asgardShake {
  0%, 100% { transform: translateX(0); }
  25% { transform: translateX(-4px); }
  75% { transform: translateX(4px); }
}

@keyframes asgardSlideDown {
  from { transform: translateY(-100%); opacity: 0; }
  to { transform: translateY(0); opacity: 1; }
}

@keyframes asgardSlideSheetUp {
  from { transform: translateY(100%); }
  to { transform: translateY(0); }
}

@keyframes asgardGrow {
  from { transform: scaleY(0); transform-origin: bottom; }
  to { transform: scaleY(1); transform-origin: bottom; }
}

@keyframes asgardCountUp {
  from { opacity: 0; transform: translateY(8px); }
  to { opacity: 1; transform: translateY(0); }
}

@keyframes asgardRipple {
  to { transform: scale(2.5); opacity: 0; }
}

/* ═══════ SELECTION ═══════ */
::selection { background: var(--selection); }

/* ═══════ SAFE AREAS ═══════ */
@supports (padding: env(safe-area-inset-top)) {
  .asgard-content {
    padding-top: env(safe-area-inset-top);
  }
  .asgard-tabbar {
    padding-bottom: calc(6px + env(safe-area-inset-bottom));
  }
}
    `;
  }

  /* ──────────────── ANIMATION HELPER ──────────────── */
  function anim(delay = 0) {
    return {
      animation: `asgardSlideUp 0.4s cubic-bezier(.34,1.56,.64,1) ${delay}s both`,
    };
  }

  function animPop(delay = 0) {
    return {
      animation: `asgardPopUp 0.2s cubic-bezier(.34,1.56,.64,1) ${delay}s both`,
    };
  }

  /* ──────────────── STATUS PRESETS ──────────────── */
  const statusColors = {
    success: (theme) => ({ color: theme.green, bg: theme.greenBg, border: theme.greenBorder }),
    danger:  (theme) => ({ color: theme.red, bg: theme.redBg, border: theme.redBorder }),
    warning: (theme) => ({ color: theme.orange, bg: theme.orangeBg, border: theme.orangeBorder }),
    info:    (theme) => ({ color: theme.blue, bg: theme.blueBg, border: theme.blueBorder }),
    neutral: (theme) => ({ color: theme.textTer, bg: theme.surfaceAlt, border: theme.border }),
    gold:    (theme) => ({ color: theme.gold, bg: theme.goldBg, border: theme.goldBorder }),
  };

  function status(type) {
    const fn = statusColors[type] || statusColors.neutral;
    return fn(t);
  }

  /* ──────────────── FONT HELPER ──────────────── */
  function font(scale) {
    const f = typography[scale] || typography.base;
    const style = {
      fontSize: f.size,
      fontWeight: f.weight,
      lineHeight: f.lineHeight,
    };
    if (f.letterSpacing) style.letterSpacing = f.letterSpacing;
    if (f.textTransform) style.textTransform = f.textTransform;
    return style;
  }

  /* ──────────────── THEME TOGGLE COMPONENT ──────────────── */
  function createThemeToggle() {
    const toggle = document.createElement('button');
    toggle.className = 'asgard-theme-toggle';
    toggle.setAttribute('aria-label', 'Переключить тему');
    updateToggleVisual(toggle);

    toggle.addEventListener('click', () => {
      toggleTheme();
      updateToggleVisual(toggle);
    });

    window.addEventListener('asgard:theme', () => updateToggleVisual(toggle));

    Object.assign(toggle.style, {
      width: '52px',
      height: '28px',
      borderRadius: '14px',
      border: 'none',
      padding: '2px',
      cursor: 'pointer',
      position: 'relative',
      transition: 'background 0.3s ease',
      display: 'flex',
      alignItems: 'center',
    });

    return toggle;
  }

  function updateToggleVisual(toggle) {
    const isDark = currentTheme === 'dark';
    toggle.style.background = isDark ? 'var(--surface-alt)' : 'var(--blue)';
    toggle.innerHTML = `
      <span style="
        width:24px;height:24px;border-radius:50%;
        background:${isDark ? '#1A1A1F' : '#FFF'};
        display:flex;align-items:center;justify-content:center;
        transform:translateX(${isDark ? '0px' : '24px'});
        transition:transform 0.3s cubic-bezier(.34,1.56,.64,1);
        font-size:14px;
      ">${isDark ? '🌙' : '☀️'}</span>
    `;
  }

  /* ──────────────── UTILITY ──────────────── */
  function camelToDash(str) {
    return str.replace(/([A-Z])/g, '-$1').toLowerCase();
  }

  function css(tokenName) {
    return `var(--${camelToDash(tokenName)})`;
  }

  /* ──────────────── PUBLIC API ──────────────── */
  return {
    get t() { return t; },
    themes,
    typography,
    spacing,
    radius,
    setTheme,
    toggleTheme,
    getTheme,
    injectStyles,
    anim,
    animPop,
    status,
    font,
    css,
    createThemeToggle,
  };
})();

// Global export
if (typeof window !== 'undefined') {
  window.DS = DS;
}
