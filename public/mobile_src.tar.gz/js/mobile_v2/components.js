/**
 * ASGARD CRM — Mobile Components v2.0
 * 26 UI-компонентов: Header, HeroCard, Card, Badge, FilterPills,
 * Stats, Section, List, Empty, Skeleton, Toast, BottomSheet, Confirm,
 * FAB, TablePage, BarChart, MiniChart, BigNumber, Form, FullWidthBtn,
 * DetailFields, ProgressBar, Tabs, QuickActions, MimirBanner, SearchBar
 */

const M = (() => {
  const el = (tag, attrs = {}, children) => {
    const element = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (k === 'className') element.className = v;
      else if (k === 'style' && typeof v === 'object') Object.assign(element.style, v);
      else if (k === 'innerHTML') element.innerHTML = v;
      else if (k === 'textContent') element.textContent = v;
      else if (k.startsWith('on') && typeof v === 'function') {
        element.addEventListener(k.slice(2).toLowerCase(), v);
      }
      else element.setAttribute(k, v);
    }
    if (children != null) {
      if (typeof children === 'string') element.textContent = children;
      else if (children instanceof HTMLElement) element.appendChild(children);
      else if (Array.isArray(children)) {
        children.forEach(c => {
          if (c instanceof HTMLElement) element.appendChild(c);
          else if (typeof c === 'string') element.appendChild(document.createTextNode(c));
          else if (c != null && typeof c === 'object' && c.nodeType) element.appendChild(c);
        });
      }
    }
    return element;
  };

  /* ══════════════════════════════════════════════
     1. HEADER
     ══════════════════════════════════════════════ */
  function Header({ title, subtitle, back = false, backHref, actions = [], transparent = false }) {
    const header = el('header', {
      className: 'mc-header',
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '12px var(--sp-page)',
        paddingTop: '12px',
        background: transparent ? 'transparent' : 'var(--surface)',
        borderBottom: transparent ? 'none' : '1px solid var(--border)',
        position: 'sticky',
        top: 0,
        zIndex: 50,
        backdropFilter: transparent ? 'none' : 'blur(20px)',
        WebkitBackdropFilter: transparent ? 'none' : 'blur(20px)',
        minHeight: '52px',
      },
    });

    // Left: back + titles
    const left = el('div', { style: { display: 'flex', alignItems: 'center', gap: '10px', flex: 1, minWidth: 0 } });

    if (back) {
      const backBtn = el('button', {
        className: 'mc-header__back',
        style: {
          background: 'none', border: 'none', cursor: 'pointer', padding: '4px',
          color: 'var(--text)', display: 'flex', alignItems: 'center', flexShrink: 0,
        },
        innerHTML: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>',
        onClick: () => {
          if (backHref) Router.navigate(backHref);
          else Router.back();
        },
      });
      left.appendChild(backBtn);
    }

    const titleWrap = el('div', { style: { minWidth: 0, flex: 1 } });
    if (subtitle) {
      titleWrap.appendChild(el('div', {
        style: {
          ...DS.font('label'),
          color: transparent ? 'rgba(255,255,255,0.55)' : 'var(--text-ter)',
          marginBottom: '2px',
        },
        textContent: subtitle,
      }));
    }
    titleWrap.appendChild(el('div', {
      style: {
        ...DS.font('lg'),
        color: transparent ? '#fff' : 'var(--text)',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
      },
      textContent: title,
    }));
    left.appendChild(titleWrap);
    header.appendChild(left);

    // Right: actions
    if (actions.length > 0) {
      const right = el('div', { style: { display: 'flex', gap: '8px', flexShrink: 0 } });
      actions.forEach(action => {
        const btn = el('button', {
          style: {
            background: 'none', border: 'none', cursor: 'pointer', padding: '6px',
            color: transparent ? '#fff' : 'var(--text)', display: 'flex',
            alignItems: 'center', justifyContent: 'center',
          },
          innerHTML: action.icon,
          onClick: action.onClick,
        });
        right.appendChild(btn);
      });
      header.appendChild(right);
    }

    return header;
  }

  /* ══════════════════════════════════════════════
     2. HERO CARD
     ══════════════════════════════════════════════ */
  function HeroCard({ label, value, valuePrefix = '', valueSuffix = '', details = [], gradient }) {
    const card = el('div', {
      className: 'mc-hero',
      style: {
        background: gradient || 'var(--hero-grad)',
        borderRadius: 'var(--r-hero)',
        padding: '20px',
        position: 'relative',
        overflow: 'hidden',
        boxShadow: 'var(--hero-shadow)',
        color: '#fff',
        ...DS.anim(0.05),
      },
    });

    // Logo watermark
    card.appendChild(el('div', {
      style: {
        position: 'absolute', top: '14px', right: '18px',
        fontSize: '16px', fontWeight: 800, opacity: 0.25, letterSpacing: '2px',
      },
      textContent: 'ASGARD',
    }));

    // Label
    if (label) {
      card.appendChild(el('div', {
        style: { fontSize: '11px', fontWeight: 500, opacity: 0.55, marginBottom: '4px' },
        textContent: label,
      }));
    }

    // Animated value
    const valEl = el('div', {
      style: { ...DS.font('hero'), color: '#fff', marginBottom: details.length ? '14px' : 0 },
    });
    const numEl = el('span');
    valEl.appendChild(document.createTextNode(valuePrefix));
    valEl.appendChild(numEl);
    valEl.appendChild(document.createTextNode(valueSuffix));
    card.appendChild(valEl);

    animateNumber(numEl, value);

    // Details row
    if (details.length) {
      const row = el('div', { style: { display: 'flex', gap: '20px' } });
      details.forEach(d => {
        const item = el('div');
        item.appendChild(el('div', {
          style: { fontSize: '10px', opacity: 0.55, marginBottom: '2px', letterSpacing: '0.3px' },
          textContent: d.label,
        }));
        item.appendChild(el('div', {
          style: { fontSize: '14px', fontWeight: 600, color: d.color || '#fff' },
          textContent: d.value,
        }));
        row.appendChild(item);
      });
      card.appendChild(row);
    }

    return card;
  }

  function animateNumber(el, target, duration = 900) {
    const num = parseFloat(String(target).replace(/[^\d.\u00a0\s-]/g, '').replace(/\s/g, ''));
    if (isNaN(num)) { el.textContent = target; return; }

    const fmt = new Intl.NumberFormat('ru-RU');
    const start = performance.now();

    function update(now) {
      const t = Math.min((now - start) / duration, 1);
      const ease = 1 - Math.pow(1 - t, 3); // cubicOut
      const current = Math.round(num * ease);

      // Always format with spaces (12 450 000)
      el.textContent = fmt.format(current);

      if (t < 1) requestAnimationFrame(update);
      else {
        // Final value — use original string if provided, else formatted number
        if (typeof target === 'string') {
          el.textContent = target;
        } else {
          el.textContent = fmt.format(num);
        }
      }
    }
    requestAnimationFrame(update);
  }

  /* ══════════════════════════════════════════════
     3. CARD
     ══════════════════════════════════════════════ */
  function Card({ title, subtitle, badge, badgeColor, fields = [], actions = [], href, arrow = true, time, swipeActions, onClick, style: customStyle, animDelay = 0 }) {
    // Left color border based on status
    const statusBorderColors = {
      info: 'var(--blue)', success: 'var(--green)', warning: 'var(--orange)',
      danger: 'var(--red)', gold: 'var(--gold)', neutral: 'var(--text-ter)',
    };
    const leftBorder = badgeColor && statusBorderColors[badgeColor];

    const card = el('div', {
      className: 'mc-card',
      style: {
        background: 'var(--surface)',
        borderRadius: 'var(--r-xl)',
        border: '1px solid var(--border)',
        borderLeft: leftBorder ? `3px solid ${leftBorder}` : '1px solid var(--border)',
        padding: '14px 16px',
        boxShadow: 'var(--shadow)',
        cursor: (href || onClick) ? 'pointer' : 'default',
        transition: 'box-shadow 0.2s ease, transform 0.15s ease',
        overflow: 'hidden',
        position: 'relative',
        ...DS.anim(animDelay),
        ...customStyle,
      },
    });

    if (href || onClick) {
      card.addEventListener('click', () => {
        if (onClick) onClick();
        else if (href) Router.navigate(href);
      });
      card.addEventListener('touchstart', () => card.style.transform = 'scale(0.98)', { passive: true });
      card.addEventListener('touchend', () => card.style.transform = '', { passive: true });
    }

    // Top row: title + badge + arrow
    const topRow = el('div', { style: { display: 'flex', alignItems: 'center', gap: '8px', marginBottom: fields.length ? '8px' : 0 } });

    const titleArea = el('div', { style: { flex: 1, minWidth: 0 } });
    titleArea.appendChild(el('div', {
      style: { ...DS.font('md'), color: 'var(--text)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' },
      textContent: title,
    }));
    if (subtitle) {
      titleArea.appendChild(el('div', {
        style: { ...DS.font('sm'), color: 'var(--text-sec)', marginTop: '2px' },
        textContent: subtitle,
      }));
    }
    topRow.appendChild(titleArea);

    if (time) {
      topRow.appendChild(el('span', {
        style: { ...DS.font('xs'), color: 'var(--text-ter)', flexShrink: 0 },
        textContent: time,
      }));
    }

    if (badge) {
      topRow.appendChild(Badge({ text: badge, color: badgeColor }));
    }

    if ((href || onClick) && arrow) {
      topRow.appendChild(el('span', {
        style: { color: 'var(--text-ter)', fontSize: '16px', flexShrink: 0 },
        innerHTML: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>',
      }));
    }

    card.appendChild(topRow);

    // Fields
    if (fields.length) {
      const fieldsWrap = el('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '4px 16px' } });
      fields.forEach(f => {
        const pair = el('div', { style: { display: 'flex', gap: '4px', alignItems: 'baseline' } });
        pair.appendChild(el('span', {
          style: { ...DS.font('sm'), color: 'var(--text-ter)' },
          textContent: f.label + ':',
        }));
        pair.appendChild(el('span', {
          style: { ...DS.font('sm'), color: 'var(--text-sec)', fontWeight: 500 },
          textContent: f.value,
        }));
        fieldsWrap.appendChild(pair);
      });
      card.appendChild(fieldsWrap);
    }

    // Actions row
    if (actions.length) {
      const actRow = el('div', { style: { display: 'flex', gap: '8px', marginTop: '10px', borderTop: '1px solid var(--border)', paddingTop: '10px' } });
      actions.forEach(a => {
        const btn = el('button', {
          style: {
            background: 'none', border: 'none', cursor: 'pointer', padding: '4px 8px',
            ...DS.font('sm'), color: 'var(--blue)', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '4px',
          },
          onClick: (e) => { e.stopPropagation(); a.onClick(); },
        });
        if (a.icon) btn.innerHTML = a.icon + ' ';
        btn.appendChild(document.createTextNode(a.label));
        actRow.appendChild(btn);
      });
      card.appendChild(actRow);
    }

    // Swipe actions
    if (swipeActions && swipeActions.length) {
      setTimeout(() => Gestures.setupSwipeActions(card, swipeActions), 0);
    }

    return card;
  }

  /* ══════════════════════════════════════════════
     4. BADGE
     ══════════════════════════════════════════════ */
  function Badge({ text, color, variant = 'solid' }) {
    const presets = {
      success: { c: 'var(--green)', bg: 'var(--green-bg)', border: 'var(--green-border)' },
      danger:  { c: 'var(--red)', bg: 'var(--red-bg)', border: 'var(--red-border)' },
      warning: { c: 'var(--orange)', bg: 'var(--orange-bg)', border: 'var(--orange-border)' },
      info:    { c: 'var(--blue)', bg: 'var(--blue-bg)', border: 'var(--blue-border)' },
      gold:    { c: 'var(--gold)', bg: 'var(--gold-bg)', border: 'var(--gold-border)' },
      neutral: { c: 'var(--text-sec)', bg: 'var(--surface-alt)', border: 'var(--border-strong)' },
    };
    const p = presets[color] || { c: color || 'var(--text-sec)', bg: (color ? color + '15' : 'var(--surface-alt)'), border: color || 'var(--border)' };

    return el('span', {
      className: 'mc-badge',
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        padding: '3px 10px',
        borderRadius: '6px',
        fontSize: '11px',
        fontWeight: 600,
        lineHeight: 1.3,
        whiteSpace: 'nowrap',
        flexShrink: 0,
        color: p.c,
        background: variant === 'solid' ? p.bg : 'transparent',
        border: `1px solid ${p.border}`,
      },
      textContent: text,
    });
  }

  /* ══════════════════════════════════════════════
     5. FILTER PILLS
     ══════════════════════════════════════════════ */
  function FilterPills({ items, onChange }) {
    const wrap = el('div', {
      className: 'mc-filter-pills asgard-no-scrollbar',
      style: {
        display: 'flex', gap: '8px', overflowX: 'auto', padding: '8px var(--sp-page)',
        scrollSnapType: 'x mandatory', WebkitOverflowScrolling: 'touch',
      },
    });

    items.forEach(item => {
      const pill = el('button', {
        className: 'mc-pill' + (item.active ? ' mc-pill--active' : ''),
        style: {
          ...pillStyle(item.active),
          scrollSnapAlign: 'start',
        },
        textContent: item.label,
        onClick: () => {
          items.forEach(i => i.active = false);
          item.active = true;
          wrap.querySelectorAll('.mc-pill').forEach((p, idx) => {
            const isActive = items[idx].active;
            p.className = 'mc-pill' + (isActive ? ' mc-pill--active' : '');
            Object.assign(p.style, pillStyle(isActive));
          });
          if (onChange) onChange(item.value);
        },
      });
      wrap.appendChild(pill);
    });

    return wrap;
  }

  function pillStyle(active) {
    return {
      padding: '6px 14px',
      borderRadius: 'var(--r-md)',
      border: active ? '1px solid var(--red-border)' : '1px solid var(--border)',
      background: active ? 'var(--red-bg)' : 'var(--surface-alt)',
      color: active ? 'var(--red)' : 'var(--text-sec)',
      fontSize: '13px',
      fontWeight: 600,
      cursor: 'pointer',
      whiteSpace: 'nowrap',
      transition: 'all 0.2s ease',
      flexShrink: 0,
    };
  }

  /* ══════════════════════════════════════════════
     6. STATS
     ══════════════════════════════════════════════ */
  function Stats({ items }) {
    const grid = el('div', {
      className: 'mc-stats',
    });
    // Force grid layout with !important to prevent desktop CSS overrides
    grid.style.setProperty('display', 'grid', 'important');
    grid.style.setProperty('grid-template-columns', 'repeat(2, 1fr)', 'important');
    grid.style.setProperty('gap', 'var(--sp-gap)', 'important');
    grid.style.setProperty('padding', '0 var(--sp-page)');

    items.forEach((item, i) => {
      const cell = el('div', {
        className: 'mc-stat',
        style: {
          background: 'var(--surface)',
          borderRadius: 'var(--r-lg)',
          padding: '14px',
          border: '1px solid var(--border)',
          boxShadow: 'var(--shadow)',
          cursor: item.href ? 'pointer' : 'default',
          ...DS.anim(i * 0.05),
        },
      });

      if (item.href) {
        cell.addEventListener('click', () => Router.navigate(item.href));
      }

      const row = el('div', { style: { display: 'flex', alignItems: 'center', gap: '8px' } });
      if (item.icon) {
        row.appendChild(el('span', { style: { fontSize: '20px' }, textContent: item.icon }));
      }
      const valEl = el('div', {
        style: {
          ...DS.font('xl'),
          color: item.color || 'var(--text)',
        },
      });
      if (typeof item.value === 'number') {
        const numSpan = el('span');
        valEl.appendChild(numSpan);
        animateNumber(numSpan, item.value);
      } else {
        valEl.textContent = item.value;
      }
      row.appendChild(valEl);
      cell.appendChild(row);

      cell.appendChild(el('div', {
        style: { ...DS.font('sm'), color: 'var(--text-sec)', marginTop: '4px' },
        textContent: item.label,
      }));

      grid.appendChild(cell);
    });

    return grid;
  }

  /* ══════════════════════════════════════════════
     7. SECTION
     ══════════════════════════════════════════════ */
  function Section({ title, content, collapsible = false, action, collapsed: initCollapsed = false }) {
    const section = el('div', {
      className: 'mc-section',
      style: { marginBottom: '16px' },
    });

    // Header
    const head = el('div', {
      style: {
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '0 var(--sp-page)', marginBottom: '10px',
      },
    });

    const titleRow = el('div', {
      style: { display: 'flex', alignItems: 'center', gap: '8px', cursor: collapsible ? 'pointer' : 'default' },
    });
    titleRow.appendChild(el('span', {
      style: { ...DS.font('md'), color: 'var(--text)' },
      textContent: title,
    }));

    let chevron;
    if (collapsible) {
      chevron = el('span', {
        style: { fontSize: '12px', color: 'var(--text-ter)', transition: 'transform 0.3s ease', display: 'inline-block' },
        textContent: '▾',
      });
      titleRow.appendChild(chevron);
    }
    head.appendChild(titleRow);

    if (action) {
      const actionBtn = el('a', {
        style: { ...DS.font('sm'), color: 'var(--blue)', fontWeight: 600, textDecoration: 'none', cursor: 'pointer' },
        textContent: action.label,
      });
      if (action.href) actionBtn.href = '#' + action.href;
      if (action.onClick) actionBtn.addEventListener('click', action.onClick);
      else if (action.href) actionBtn.addEventListener('click', (e) => { e.preventDefault(); Router.navigate(action.href); });
      head.appendChild(actionBtn);
    }

    section.appendChild(head);

    // Content
    const body = el('div', {
      className: 'mc-section__body',
      style: {
        overflow: 'hidden',
        transition: 'max-height 0.35s ease, opacity 0.3s ease',
      },
    });

    if (content instanceof HTMLElement) body.appendChild(content);
    else if (typeof content === 'string') body.innerHTML = content;

    let isCollapsed = initCollapsed;
    if (collapsible && isCollapsed) {
      body.style.maxHeight = '0';
      body.style.opacity = '0';
      if (chevron) chevron.style.transform = 'rotate(-90deg)';
    } else {
      body.style.maxHeight = 'none';
      body.style.opacity = '1';
    }

    if (collapsible) {
      titleRow.addEventListener('click', () => {
        isCollapsed = !isCollapsed;
        if (isCollapsed) {
          body.style.maxHeight = body.scrollHeight + 'px';
          requestAnimationFrame(() => {
            body.style.maxHeight = '0';
            body.style.opacity = '0';
          });
          if (chevron) chevron.style.transform = 'rotate(-90deg)';
        } else {
          body.style.maxHeight = body.scrollHeight + 'px';
          body.style.opacity = '1';
          if (chevron) chevron.style.transform = 'rotate(0deg)';
          setTimeout(() => { body.style.maxHeight = 'none'; }, 350);
        }
      });
    }

    section.appendChild(body);
    return section;
  }

  /* ══════════════════════════════════════════════
     8. LIST
     ══════════════════════════════════════════════ */
  function List({ items, renderItem, empty, divider = true }) {
    if (!items || items.length === 0) {
      return empty || Empty({});
    }

    const list = el('div', {
      className: 'mc-list',
      style: { display: 'flex', flexDirection: 'column', gap: '0', padding: '0 var(--sp-page)' },
    });

    items.forEach((item, i) => {
      const rendered = renderItem(item, i);
      if (rendered) {
        list.appendChild(rendered);
        // Add divider between items
        if (divider && i < items.length - 1) {
          list.appendChild(el('div', {
            style: {
              height: '1px', background: 'var(--border)',
              margin: '0 16px',
            },
          }));
        }
      }
    });

    return list;
  }

  /* ══════════════════════════════════════════════
     9. EMPTY STATE
     ══════════════════════════════════════════════ */
  function Empty({ text, icon, type }) {
    const icons = { rune: 'ᚱ', sword: '⚔️', eagle: '🦅', shield: '🛡️', default: 'ᚱ' };
    const texts = {
      default: 'Здесь пока пусто, воин',
      search: 'Ничего не найдено',
      error: 'Произошла ошибка',
    };

    return el('div', {
      className: 'mc-empty',
      style: {
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        padding: '60px 20px', textAlign: 'center',
        ...DS.anim(0.1),
      },
    }, [
      el('div', {
        style: {
          fontSize: '72px', marginBottom: '16px',
          color: 'var(--gold)',
          filter: 'drop-shadow(0 4px 12px rgba(212,168,67,0.5))',
        },
        textContent: icon || icons[type] || icons.default,
      }),
      el('div', { style: { ...DS.font('md'), color: 'var(--text-sec)' }, textContent: text || texts[type] || texts.default }),
    ]);
  }

  /* ══════════════════════════════════════════════
     10. SKELETON
     ══════════════════════════════════════════════ */
  function Skeleton({ type = 'card', count = 3 }) {
    const wrap = el('div', {
      className: 'mc-skeleton',
      style: { display: 'flex', flexDirection: 'column', gap: 'var(--sp-gap)', padding: '0 var(--sp-page)' },
    });

    for (let i = 0; i < count; i++) {
      let skel;
      if (type === 'hero') {
        skel = el('div', { style: { ...shimmerBlock(), height: '120px', borderRadius: 'var(--r-hero)' } });
      } else if (type === 'stats') {
        const grid = el('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' } });
        for (let j = 0; j < 4; j++) {
          grid.appendChild(el('div', { style: { ...shimmerBlock(), height: '64px', borderRadius: 'var(--r-lg)' } }));
        }
        skel = grid;
      } else if (type === 'list') {
        skel = el('div', { style: { display: 'flex', gap: '12px', alignItems: 'center', padding: '10px 0' } });
        skel.appendChild(el('div', { style: { ...shimmerBlock(), width: '40px', height: '40px', borderRadius: '50%', flexShrink: 0 } }));
        const lines = el('div', { style: { flex: 1, display: 'flex', flexDirection: 'column', gap: '6px' } });
        lines.appendChild(el('div', { style: { ...shimmerBlock(), height: '14px', width: (60 + i * 10) + '%', borderRadius: '4px' } }));
        lines.appendChild(el('div', { style: { ...shimmerBlock(), height: '10px', width: (30 + i * 8) + '%', borderRadius: '4px' } }));
        skel.appendChild(lines);
      } else {
        // card — varying heights for variety
        const heights = [78, 64, 52, 72, 60];
        skel = el('div', { style: { ...shimmerBlock(), height: heights[i % heights.length] + 'px', borderRadius: 'var(--r-xl)' } });
      }
      wrap.appendChild(skel);
    }

    return wrap;
  }

  function shimmerBlock() {
    const isDark = DS.getTheme() === 'dark';
    const grad = isDark
      ? 'linear-gradient(90deg, #222228 25%, #2A2A32 50%, #222228 75%)'
      : 'linear-gradient(90deg, #F7F7FA 25%, #EDEDF0 50%, #F7F7FA 75%)';
    return {
      background: grad,
      backgroundSize: '200% 100%',
      animation: 'asgardShimmer 1.5s infinite ease-in-out',
      borderRadius: '8px',
    };
  }

  /* ══════════════════════════════════════════════
     11. TOAST
     ══════════════════════════════════════════════ */
  function Toast({ message, type = 'info', duration = 3000 }) {
    const colors = {
      success: { bg: 'var(--green-bg)', border: 'var(--green-border)', color: 'var(--green)', icon: '✓' },
      error:   { bg: 'var(--red-bg)', border: 'var(--red-border)', color: 'var(--red)', icon: '✕' },
      info:    { bg: 'var(--blue-bg)', border: 'var(--blue-border)', color: 'var(--blue)', icon: 'ℹ' },
    };
    const c = colors[type] || colors.info;

    const toast = el('div', {
      className: 'mc-toast',
      style: {
        position: 'fixed', top: 'calc(12px + env(safe-area-inset-top, 0px))', left: '20px', right: '20px',
        padding: '12px 16px', borderRadius: 'var(--r-lg)', zIndex: 2000,
        background: c.bg, border: `1px solid ${c.border}`, color: c.color,
        display: 'flex', alignItems: 'center', gap: '10px',
        fontSize: '14px', fontWeight: 600, backdropFilter: 'blur(12px)', WebkitBackdropFilter: 'blur(12px)',
        animation: 'asgardSlideDown 0.35s cubic-bezier(.34,1.56,.64,1)',
        boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
      },
    });

    toast.appendChild(el('span', { textContent: c.icon, style: { fontSize: '16px' } }));
    toast.appendChild(el('span', { textContent: message, style: { flex: 1 } }));

    // Swipe up to dismiss
    let startY = 0;
    toast.addEventListener('touchstart', (e) => { startY = e.touches[0].clientY; }, { passive: true });
    toast.addEventListener('touchmove', (e) => {
      const dy = e.touches[0].clientY - startY;
      if (dy < 0) toast.style.transform = `translateY(${dy}px)`;
    }, { passive: true });
    toast.addEventListener('touchend', (e) => {
      if (parseInt(toast.style.transform.replace(/[^\d-]/g, '')) < -30) {
        dismiss();
      } else {
        toast.style.transform = '';
      }
    }, { passive: true });

    document.body.appendChild(toast);

    const timer = setTimeout(dismiss, duration);

    function dismiss() {
      clearTimeout(timer);
      toast.style.transition = 'transform 0.3s ease, opacity 0.3s ease';
      toast.style.transform = 'translateY(-100%)';
      toast.style.opacity = '0';
      setTimeout(() => toast.remove(), 300);
    }

    return toast;
  }

  /* ══════════════════════════════════════════════
     12. BOTTOM SHEET
     ══════════════════════════════════════════════ */
  function BottomSheet({ title, content, fullscreen = false, onClose }) {
    const overlay = el('div', {
      className: 'mc-sheet-overlay',
      style: {
        position: 'fixed', inset: 0, zIndex: 1500,
        background: 'var(--overlay)', backdropFilter: 'blur(4px)', WebkitBackdropFilter: 'blur(4px)',
        animation: 'asgardFadeIn 0.25s ease',
      },
    });

    const sheet = el('div', {
      className: 'mc-sheet',
      style: {
        position: 'fixed', bottom: 0, left: 0, right: 0, zIndex: 1501,
        background: 'var(--surface)', borderRadius: '20px 20px 0 0',
        maxHeight: fullscreen ? '95vh' : '70vh',
        animation: 'asgardSlideSheetUp 0.35s cubic-bezier(.34,1.56,.64,1)',
        display: 'flex', flexDirection: 'column',
        paddingBottom: 'env(safe-area-inset-bottom)',
      },
    });

    // Drag handle
    const handle = el('div', {
      style: {
        display: 'flex', justifyContent: 'center', padding: '10px 0 6px',
        cursor: 'grab', flexShrink: 0,
      },
    });
    handle.appendChild(el('div', {
      style: { width: '36px', height: '4px', borderRadius: '2px', background: 'var(--surface-alt)' },
    }));
    sheet.appendChild(handle);

    // Title
    if (title) {
      const titleBar = el('div', {
        style: {
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '0 20px 12px', borderBottom: '1px solid var(--border)',
          flexShrink: 0,
        },
      });
      titleBar.appendChild(el('div', { style: { ...DS.font('md'), color: 'var(--text)' }, textContent: title }));

      const closeBtn = el('button', {
        style: {
          background: 'var(--surface-alt)', border: 'none', borderRadius: '50%',
          width: '28px', height: '28px', display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer', color: 'var(--text-sec)', fontSize: '16px',
        },
        textContent: '✕',
        onClick: close,
      });
      titleBar.appendChild(closeBtn);
      sheet.appendChild(titleBar);
    }

    // Content
    const body = el('div', {
      style: { flex: 1, overflowY: 'auto', padding: '16px 20px', WebkitOverflowScrolling: 'touch' },
    });
    if (content instanceof HTMLElement) body.appendChild(content);
    else if (typeof content === 'string') body.innerHTML = content;
    sheet.appendChild(body);

    // Swipe down to close
    let dragStartY = 0;
    let dragging = false;
    handle.addEventListener('touchstart', (e) => { dragStartY = e.touches[0].clientY; dragging = true; }, { passive: true });
    handle.addEventListener('touchmove', (e) => {
      if (!dragging) return;
      const dy = e.touches[0].clientY - dragStartY;
      if (dy > 0) sheet.style.transform = `translateY(${dy}px)`;
    }, { passive: true });
    handle.addEventListener('touchend', () => {
      if (!dragging) return;
      dragging = false;
      const ty = parseInt(sheet.style.transform?.replace(/[^\d]/g, '') || '0');
      if (ty > 100) close();
      else { sheet.style.transition = 'transform 0.3s ease'; sheet.style.transform = ''; setTimeout(() => sheet.style.transition = '', 300); }
    }, { passive: true });

    overlay.addEventListener('click', close);

    document.body.appendChild(overlay);
    document.body.appendChild(sheet);

    function close() {
      sheet.style.transition = 'transform 0.3s ease';
      sheet.style.transform = 'translateY(100%)';
      overlay.style.transition = 'opacity 0.3s ease';
      overlay.style.opacity = '0';
      setTimeout(() => {
        overlay.remove();
        sheet.remove();
        if (onClose) onClose();
      }, 300);
    }

    return { close, sheet, body };
  }

  /* ══════════════════════════════════════════════
     13. CONFIRM DIALOG
     ══════════════════════════════════════════════ */
  function Confirm({ title, message, okText = 'Подтвердить', cancelText = 'Отмена', danger = false }) {
    return new Promise((resolve) => {
      const overlay = el('div', {
        style: {
          position: 'fixed', inset: 0, zIndex: 2000,
          background: 'var(--overlay)', backdropFilter: 'blur(4px)', WebkitBackdropFilter: 'blur(4px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px',
          animation: 'asgardFadeIn 0.2s ease',
        },
      });

      const dialog = el('div', {
        style: {
          background: 'var(--surface)', borderRadius: 'var(--r-xl)', padding: '24px',
          maxWidth: '320px', width: '100%', boxShadow: 'var(--shadow-hover)',
          ...DS.animPop(0),
        },
      });

      if (title) {
        const titleRow = el('div', { style: { display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' } });
        if (danger) titleRow.appendChild(el('span', { style: { fontSize: '20px' }, textContent: '⚠️' }));
        titleRow.appendChild(el('div', {
          style: { ...DS.font('md'), color: danger ? 'var(--red)' : 'var(--text)' },
          textContent: title,
        }));
        dialog.appendChild(titleRow);
      }

      if (message) dialog.appendChild(el('div', {
        style: { ...DS.font('base'), color: 'var(--text-sec)', marginBottom: '20px' },
        textContent: message,
      }));

      const btns = el('div', { style: { display: 'flex', gap: '10px' } });

      btns.appendChild(el('button', {
        style: {
          flex: 1, padding: '12px', borderRadius: 'var(--r-md)', border: '1px solid var(--border)',
          background: 'transparent', color: 'var(--text-sec)', fontSize: '14px', fontWeight: 600, cursor: 'pointer',
        },
        textContent: cancelText,
        onClick: () => { overlay.remove(); resolve(false); },
      }));

      btns.appendChild(el('button', {
        style: {
          flex: 1, padding: '12px', borderRadius: 'var(--r-md)', border: 'none',
          background: danger ? 'var(--red)' : 'var(--blue)', color: '#fff',
          fontSize: '14px', fontWeight: 600, cursor: 'pointer',
        },
        textContent: okText,
        onClick: () => { overlay.remove(); resolve(true); },
      }));

      dialog.appendChild(btns);
      overlay.appendChild(dialog);
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) { overlay.remove(); resolve(false); }
      });
      document.body.appendChild(overlay);
    });
  }

  /* ══════════════════════════════════════════════
     14. FAB (Floating Action Button)
     ══════════════════════════════════════════════ */
  function FAB({ icon, onClick, gradient = true, pulse = true }) {
    const fab = el('button', {
      className: 'mc-fab',
      style: {
        position: 'fixed', bottom: 'calc(80px + env(safe-area-inset-bottom, 0px))', right: '20px',
        width: '56px', height: '56px', borderRadius: '50%',
        background: gradient ? 'var(--hero-grad)' : 'var(--surface)',
        border: gradient ? 'none' : '1px solid var(--border)',
        color: gradient ? '#fff' : 'var(--text)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        boxShadow: gradient ? 'var(--fab-shadow)' : 'var(--shadow)',
        cursor: 'pointer', zIndex: 90,
        animation: pulse ? 'asgardFabPulse 3s infinite' : 'none',
        transition: 'transform 0.2s ease',
        fontSize: '24px',
      },
      onClick,
    });
    fab.innerHTML = icon || '+';

    fab.addEventListener('touchstart', () => fab.style.transform = 'scale(0.9)', { passive: true });
    fab.addEventListener('touchend', () => fab.style.transform = '', { passive: true });

    return fab;
  }

  /* ══════════════════════════════════════════════
     15. TABLE PAGE (универсальная страница-список)
     ══════════════════════════════════════════════ */
  function TablePage({ title, subtitle, items = [], renderItem, search = false, filter, chart, empty, loadMore, stats, fab: fabConfig, onRefresh, back = true, backHref, actions: headerActions }) {
    const page = el('div', { className: 'mc-table-page' });
    let filteredItems = [...items];
    let searchQuery = '';
    let currentFilter = null;
    let listContainer;
    let loading = false;

    // Header
    page.appendChild(Header({ title, subtitle, back, backHref, actions: headerActions }));

    // Search
    if (search) {
      const searchBar = SearchBar({
        placeholder: 'Поиск...',
        sticky: true,
        onSearch: (q) => {
          searchQuery = q.toLowerCase();
          rerender();
        },
      });
      page.appendChild(searchBar);
    }

    // Filter
    if (filter && filter.pills) {
      page.appendChild(FilterPills({
        items: filter.pills,
        onChange: (val) => {
          currentFilter = val;
          rerender();
        },
      }));
    }

    // Stats
    if (stats) {
      const statsWrap = el('div', { style: { marginTop: '12px', marginBottom: '4px' } });
      statsWrap.appendChild(Stats({ items: stats }));
      page.appendChild(statsWrap);
    }

    // Chart
    if (chart) {
      const chartSection = Section({
        title: chart.title || 'Динамика',
        collapsible: true,
        content: chart.type === 'bar' ? BarChart({ data: chart.data, opts: chart.opts }) : MiniChart({ data: chart.data, opts: chart.opts }),
      });
      page.appendChild(chartSection);
    }

    // List
    listContainer = el('div', {
      className: 'mc-table-page__list',
      style: { padding: '12px 0', minHeight: '200px' },
    });
    page.appendChild(listContainer);

    // FAB
    if (fabConfig) {
      page.appendChild(FAB(fabConfig));
    }

    // Refresh handler
    if (onRefresh) {
      const refreshHandler = async () => {
        loading = true;
        renderList([]);
        listContainer.appendChild(Skeleton({ type: 'card', count: 5 }));
        try {
          const newItems = await onRefresh();
          if (newItems) {
            items.length = 0;
            items.push(...newItems);
            filteredItems = [...items];
          }
        } catch (e) { console.error(e); }
        loading = false;
        rerender();
      };
      window.addEventListener('asgard:refresh', refreshHandler);
    }

    // Initial render
    rerender();

    function getFiltered() {
      let result = [...items];
      if (searchQuery) {
        result = result.filter(item => {
          const text = JSON.stringify(item).toLowerCase();
          return text.includes(searchQuery);
        });
      }
      if (currentFilter && filter && filter.filterFn) {
        result = result.filter(item => filter.filterFn(item, currentFilter));
      }
      return result;
    }

    function rerender() {
      filteredItems = getFiltered();
      renderList(filteredItems);
    }

    function renderList(data) {
      listContainer.innerHTML = '';
      if (loading) {
        listContainer.appendChild(Skeleton({ type: 'card', count: 5 }));
        return;
      }
      if (!data.length) {
        listContainer.appendChild(empty || Empty({ type: searchQuery ? 'search' : 'default' }));
        return;
      }

      const listEl = el('div', {
        style: { display: 'flex', flexDirection: 'column', gap: 'var(--sp-gap)', padding: '0 var(--sp-page)' },
      });

      // Virtual scroll for large lists
      if (data.length > 50) {
        renderVirtualList(listEl, data);
      } else {
        data.forEach((item, i) => {
          const rendered = renderItem(item, i);
          if (rendered) listEl.appendChild(rendered);
        });
      }

      listContainer.appendChild(listEl);

      // Load more
      if (loadMore && data.length >= 20) {
        const content = Layout.getContentZone();
        if (content) {
          Utils.infiniteScroll(content, async () => {
            const more = await loadMore();
            if (more && more.length) {
              items.push(...more);
              rerender();
            }
          });
        }
      }
    }

    function renderVirtualList(container, data) {
      const ITEM_HEIGHT = 84; // Approximate
      const BUFFER = 5;
      const totalHeight = data.length * ITEM_HEIGHT;
      const scrollParent = Layout.getContentZone();

      container.style.position = 'relative';
      container.style.height = totalHeight + 'px';

      let lastStart = -1;
      const rendered = new Map();

      function updateVisible() {
        if (!scrollParent) return;
        const scrollTop = scrollParent.scrollTop;
        const viewHeight = scrollParent.clientHeight;
        const start = Math.max(0, Math.floor(scrollTop / ITEM_HEIGHT) - BUFFER);
        const end = Math.min(data.length, Math.ceil((scrollTop + viewHeight) / ITEM_HEIGHT) + BUFFER);

        if (start === lastStart) return;
        lastStart = start;

        // Remove out-of-view items
        for (const [idx, el] of rendered) {
          if (idx < start || idx >= end) {
            el.remove();
            rendered.delete(idx);
          }
        }

        // Add visible items
        for (let i = start; i < end; i++) {
          if (!rendered.has(i)) {
            const item = renderItem(data[i], i);
            if (item) {
              item.style.position = 'absolute';
              item.style.top = (i * ITEM_HEIGHT) + 'px';
              item.style.left = '0';
              item.style.right = '0';
              container.appendChild(item);
              rendered.set(i, item);
            }
          }
        }
      }

      if (scrollParent) {
        scrollParent.addEventListener('scroll', Utils.throttle(updateVisible, 50), { passive: true });
      }
      updateVisible();
    }

    // Public API
    page.setItems = (newItems) => {
      items.length = 0;
      items.push(...newItems);
      rerender();
    };
    page.setLoading = (v) => { loading = v; rerender(); };

    return page;
  }

  /* ══════════════════════════════════════════════
     16. BAR CHART
     ══════════════════════════════════════════════ */
  function BarChart({ data, opts = {} }) {
    const { height = 130, color, dual = false } = opts;
    const maxVal = Math.max(...data.map(d => dual ? Math.max(d.value, d.value2 || 0) : d.value), 1);

    const chart = el('div', {
      className: 'mc-bar-chart',
      style: {
        height: height + 'px',
        display: 'flex',
        alignItems: 'flex-end',
        gap: dual ? '4px' : '6px',
        padding: '0 var(--sp-page)',
        paddingBottom: '20px',
        position: 'relative',
        ...DS.anim(0.1),
      },
    });

    data.forEach((d, i) => {
      const group = el('div', {
        style: {
          flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center',
          gap: dual ? '2px' : '0', height: '100%', justifyContent: 'flex-end',
        },
      });

      if (dual) {
        const barWrap = el('div', { style: { display: 'flex', gap: '2px', alignItems: 'flex-end', flex: 1, width: '100%' } });

        // Bar 1
        const h1 = ((d.value / maxVal) * (height - 30)) + 'px';
        const bar1 = el('div', {
          style: {
            flex: 1, height: '0', background: `linear-gradient(to top, ${color || 'var(--blue)'}, ${color || 'var(--blue-bright)'})`,
            borderRadius: '6px 6px 2px 2px', transition: `height 0.5s cubic-bezier(.34,1.56,.64,1) ${i * 0.05}s`,
            cursor: 'pointer', position: 'relative',
          },
        });
        bar1.addEventListener('click', () => {
          const existing = chart.querySelector('.mc-bar-tooltip');
          if (existing) existing.remove();
          const tooltip = el('div', {
            className: 'mc-bar-tooltip',
            style: {
              position: 'absolute', bottom: '100%', left: '50%', transform: 'translateX(-50%)',
              background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: '6px',
              padding: '4px 8px', fontSize: '11px', fontWeight: 600, color: 'var(--text)',
              whiteSpace: 'nowrap', boxShadow: 'var(--shadow)', zIndex: 10, marginBottom: '4px',
              ...DS.animPop(0),
            },
            textContent: typeof d.value === 'number' ? Utils.formatNumber(d.value) : d.value,
          });
          bar1.appendChild(tooltip);
          setTimeout(() => tooltip.remove(), 2000);
        });
        barWrap.appendChild(bar1);

        // Bar 2
        const h2 = (((d.value2 || 0) / maxVal) * (height - 30)) + 'px';
        const bar2 = el('div', {
          style: {
            flex: 1, height: '0', background: 'linear-gradient(to top, var(--red), var(--red-bright))',
            borderRadius: '6px 6px 2px 2px', transition: `height 0.5s cubic-bezier(.34,1.56,.64,1) ${i * 0.05 + 0.05}s`,
            cursor: 'pointer', position: 'relative',
          },
        });
        bar2.addEventListener('click', () => {
          const existing = chart.querySelector('.mc-bar-tooltip');
          if (existing) existing.remove();
          const tooltip = el('div', {
            className: 'mc-bar-tooltip',
            style: {
              position: 'absolute', bottom: '100%', left: '50%', transform: 'translateX(-50%)',
              background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: '6px',
              padding: '4px 8px', fontSize: '11px', fontWeight: 600, color: 'var(--text)',
              whiteSpace: 'nowrap', boxShadow: 'var(--shadow)', zIndex: 10, marginBottom: '4px',
              ...DS.animPop(0),
            },
            textContent: typeof d.value2 === 'number' ? Utils.formatNumber(d.value2) : (d.value2 || 0),
          });
          bar2.appendChild(tooltip);
          setTimeout(() => tooltip.remove(), 2000);
        });
        barWrap.appendChild(bar2);

        group.appendChild(barWrap);

        // Animate
        setTimeout(() => {
          barWrap.children[0].style.height = h1;
          barWrap.children[1].style.height = h2;
        }, 50);
      } else {
        const h = ((d.value / maxVal) * (height - 30)) + 'px';
        const bar = el('div', {
          style: {
            width: '100%', height: '0',
            background: color ? `linear-gradient(to top, ${color}, ${color})` : 'linear-gradient(to top, var(--blue), var(--red-bright))',
            borderRadius: '6px 6px 2px 2px',
            transition: `height 0.5s cubic-bezier(.34,1.56,.64,1) ${i * 0.05}s`,
            cursor: 'pointer',
            position: 'relative',
          },
        });

        // Tooltip
        bar.addEventListener('click', () => {
          const existing = chart.querySelector('.mc-bar-tooltip');
          if (existing) existing.remove();
          const tooltip = el('div', {
            className: 'mc-bar-tooltip',
            style: {
              position: 'absolute', bottom: '100%', left: '50%', transform: 'translateX(-50%)',
              background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: '6px',
              padding: '4px 8px', fontSize: '11px', fontWeight: 600, color: 'var(--text)',
              whiteSpace: 'nowrap', boxShadow: 'var(--shadow)', zIndex: 10, marginBottom: '4px',
              ...DS.animPop(0),
            },
            textContent: typeof d.value === 'number' ? Utils.formatNumber(d.value) : d.value,
          });
          bar.appendChild(tooltip);
          setTimeout(() => tooltip.remove(), 2000);
        });

        group.appendChild(bar);
        setTimeout(() => { bar.style.height = h; }, 50);
      }

      // Label
      const labelEl = el('div', {
        className: 'mc-bar-label',
        style: {
          fontSize: '9px', fontWeight: 500, color: 'var(--text-ter)', marginTop: '4px',
          textAlign: 'center', position: 'absolute', bottom: 0,
          maxWidth: '100%', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
          lineHeight: '1.1',
        },
        textContent: d.label,
      });
      if (i % 2 === 1) labelEl.dataset.even = '';
      group.appendChild(labelEl);

      chart.appendChild(group);
    });

    return chart;
  }

  /* ══════════════════════════════════════════════
     17. MINI CHART (Sparkline)
     ══════════════════════════════════════════════ */
  function MiniChart({ data, opts = {} }) {
    const { color = 'var(--red)', height = 36 } = opts;
    if (!data || data.length < 2) return el('div');

    const max = Math.max(...data);
    const min = Math.min(...data);
    const range = max - min || 1;
    const w = 200;
    const h = height;

    const points = data.map((v, i) => {
      const x = (i / (data.length - 1)) * w;
      const y = h - ((v - min) / range) * (h - 4) - 2;
      return { x, y };
    });

    // Smooth cubic bezier path
    let path = `M ${points[0].x} ${points[0].y}`;
    for (let i = 1; i < points.length; i++) {
      const prev = points[i - 1];
      const curr = points[i];
      const cpx1 = prev.x + (curr.x - prev.x) / 3;
      const cpx2 = prev.x + (curr.x - prev.x) * 2 / 3;
      path += ` C ${cpx1} ${prev.y} ${cpx2} ${curr.y} ${curr.x} ${curr.y}`;
    }

    const areaPath = path + ` L ${w} ${h} L 0 ${h} Z`;

    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', `0 0 ${w} ${h}`);
    svg.setAttribute('width', '100%');
    svg.setAttribute('height', h);
    svg.style.display = 'block';

    const gradId = 'mcgrad' + Math.random().toString(36).substr(2, 6);
    svg.innerHTML = `
      <defs>
        <linearGradient id="${gradId}" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="${color}" stop-opacity="0.3"/>
          <stop offset="100%" stop-color="${color}" stop-opacity="0"/>
        </linearGradient>
      </defs>
      <path d="${areaPath}" fill="url(#${gradId})" />
      <path d="${path}" fill="none" stroke="${color}" stroke-width="1.5" stroke-linecap="round"/>
    `;

    return svg;
  }

  /* ══════════════════════════════════════════════
     18. BIG NUMBER
     ══════════════════════════════════════════════ */
  function BigNumber({ value, label, prefix = '', suffix = '', color, icon, trend }) {
    const wrap = el('div', {
      className: 'mc-big-num',
      style: { display: 'flex', flexDirection: 'column', ...DS.anim(0.05) },
    });

    const row = el('div', { style: { display: 'flex', alignItems: 'baseline', gap: '6px' } });

    if (icon) row.appendChild(el('span', { style: { fontSize: '20px' }, textContent: icon }));

    if (prefix) row.appendChild(el('span', { style: { ...DS.font('xl'), color: color || 'var(--text)' }, textContent: prefix }));

    const numEl = el('span', { style: { ...DS.font('hero'), color: color || 'var(--text)' } });
    const numSpan = el('span');
    numEl.appendChild(numSpan);
    animateNumber(numSpan, value);
    row.appendChild(numEl);

    if (suffix) row.appendChild(el('span', { style: { ...DS.font('xl'), color: color || 'var(--text)' }, textContent: suffix }));

    if (trend) {
      const trendColor = trend.up ? 'var(--green)' : 'var(--red)';
      row.appendChild(el('span', {
        style: { ...DS.font('sm'), color: trendColor, fontWeight: 600, marginLeft: '6px' },
        textContent: (trend.up ? '↑' : '↓') + ' ' + trend.value,
      }));
    }

    wrap.appendChild(row);

    if (label) {
      wrap.appendChild(el('div', {
        style: { ...DS.font('sm'), color: 'var(--text-sec)', marginTop: '2px' },
        textContent: label,
      }));
    }

    return wrap;
  }

  /* ══════════════════════════════════════════════
     19. FORM
     ══════════════════════════════════════════════ */
  function Form({ fields, onSubmit, submitLabel = 'Сохранить' }) {
    const form = el('form', {
      className: 'mc-form',
      style: { padding: '0 var(--sp-page)', maxWidth: '100%', overflow: 'hidden' },
      onSubmit: (e) => {
        e.preventDefault();
        const data = {};
        let valid = true;
        fields.forEach(f => {
          const input = form.querySelector(`[name="${f.id}"]`);
          if (!input) return;
          const val = f.type === 'toggle' ? input.checked : input.value;
          if (f.required && !val) {
            valid = false;
            showFieldError(input, 'Обязательное поле');
          }
          data[f.id] = val;
        });
        if (valid && onSubmit) onSubmit(data);
      },
    });

    let currentSection = null;

    fields.forEach((f, i) => {
      // Section heading
      if (f.section && f.section !== currentSection) {
        currentSection = f.section;
        form.appendChild(el('div', {
          style: {
            ...DS.font('md'), color: 'var(--text)', marginTop: i > 0 ? '20px' : '0',
            marginBottom: '12px',
          },
          textContent: f.section,
        }));
      }

      const group = el('div', {
        className: 'mc-form__group',
        style: { marginBottom: '14px', position: 'relative' },
      });

      if (f.type === 'toggle') {
        // Toggle row
        const row = el('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '12px', maxWidth: '100%' } });
        row.appendChild(el('label', {
          style: { ...DS.font('base'), color: 'var(--text)', flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
          textContent: f.label,
        }));

        const toggle = el('input', {
          type: 'checkbox',
          name: f.id,
          style: {
            width: '44px', minWidth: '44px', maxWidth: '44px', height: '24px',
            appearance: 'none', WebkitAppearance: 'none',
            background: f.value ? 'var(--red)' : 'var(--surface-alt)',
            borderRadius: '12px', position: 'relative', cursor: 'pointer', transition: 'background 0.3s ease',
            border: '1px solid var(--border)', flexShrink: 0,
          },
        });
        if (f.value) toggle.checked = true;
        toggle.addEventListener('change', () => {
          toggle.style.background = toggle.checked ? 'var(--red)' : 'var(--surface-alt)';
        });
        row.appendChild(toggle);
        group.appendChild(row);
      } else if (f.type === 'select') {
        // Select
        group.appendChild(el('label', {
          style: { ...DS.font('sm'), color: 'var(--text-sec)', marginBottom: '4px', display: 'block' },
          textContent: f.label,
        }));

        const select = el('select', {
          name: f.id,
          style: {
            ...inputStyle(),
            appearance: 'none', WebkitAppearance: 'none',
            backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='%238E8E93' stroke-width='2.5'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E")`,
            backgroundRepeat: 'no-repeat', backgroundPosition: 'right 12px center',
          },
        });
        if (f.placeholder) {
          select.appendChild(el('option', { value: '', textContent: f.placeholder, disabled: true, selected: !f.value }));
        }
        (f.options || []).forEach(opt => {
          const option = el('option', { value: opt.value || opt, textContent: opt.label || opt });
          if (f.value === (opt.value || opt)) option.selected = true;
          select.appendChild(option);
        });
        group.appendChild(select);
      } else if (f.type === 'textarea') {
        group.appendChild(el('label', {
          style: { ...DS.font('sm'), color: 'var(--text-sec)', marginBottom: '4px', display: 'block' },
          textContent: f.label,
        }));
        group.appendChild(el('textarea', {
          name: f.id,
          placeholder: f.placeholder || '',
          style: { ...inputStyle(), minHeight: '80px', resize: 'vertical' },
          textContent: f.value || '',
        }));
      } else {
        // Standard input with floating label
        const inputWrap = el('div', { style: { position: 'relative' } });

        const input = el('input', {
          type: f.type || 'text',
          name: f.id,
          placeholder: ' ',
          value: f.value || '',
          style: inputStyle(true),
        });
        if (f.required) input.required = true;

        const label = el('label', {
          style: {
            position: 'absolute', left: '16px', top: '15px',
            fontSize: '14px', fontWeight: 400, color: 'var(--text-ter)',
            transition: 'all 0.2s cubic-bezier(.34,1.56,.64,1)', pointerEvents: 'none',
            transformOrigin: 'left top',
          },
          textContent: f.label,
        });

        // Float label on focus/filled
        const floatLabel = () => {
          const filled = input.value || document.activeElement === input;
          if (filled) {
            label.style.top = '6px';
            label.style.fontSize = '10px';
            label.style.fontWeight = '500';
            label.style.color = document.activeElement === input ? 'var(--red)' : 'var(--text-sec)';
            label.style.letterSpacing = '0.3px';
          } else {
            label.style.top = '15px';
            label.style.fontSize = '14px';
            label.style.fontWeight = '400';
            label.style.color = 'var(--text-ter)';
            label.style.letterSpacing = '0';
          }
        };
        input.addEventListener('focus', () => {
          input.style.borderColor = 'var(--red)';
          input.style.boxShadow = '0 0 0 3px var(--red-bg)';
          floatLabel();
        });
        input.addEventListener('blur', () => {
          input.style.borderColor = 'var(--border)';
          input.style.boxShadow = 'none';
          floatLabel();
        });
        input.addEventListener('input', floatLabel);

        inputWrap.appendChild(input);
        inputWrap.appendChild(label);
        group.appendChild(inputWrap);

        // Initial float check
        if (f.value) setTimeout(floatLabel, 0);
      }

      // Error placeholder
      group.appendChild(el('div', {
        className: 'mc-form__error',
        style: { ...DS.font('xs'), color: 'var(--red)', marginTop: '4px', display: 'none' },
      }));

      form.appendChild(group);
    });

    // Submit button
    form.appendChild(FullWidthBtn({ label: submitLabel, onClick: () => form.dispatchEvent(new Event('submit')) }));

    return form;
  }

  function inputStyle(floating = false) {
    return {
      width: '100%',
      padding: floating ? '22px 16px 8px' : '14px 16px',
      borderRadius: 'var(--r-md)',
      border: '1px solid var(--border)',
      background: 'var(--input-bg)',
      color: 'var(--text)',
      fontSize: '14px',
      outline: 'none',
      transition: 'border-color 0.2s ease, padding 0.2s ease',
      boxSizing: 'border-box',
      fontFamily: 'inherit',
    };
  }

  function showFieldError(input, msg) {
    input.style.borderColor = 'var(--red)';
    input.style.animation = 'asgardShake 0.3s ease';
    const group = input.closest('.mc-form__group');
    if (group) {
      const err = group.querySelector('.mc-form__error');
      if (err) { err.textContent = msg; err.style.display = 'block'; }
    }
    setTimeout(() => { input.style.animation = ''; }, 300);
    input.addEventListener('input', () => {
      input.style.borderColor = 'var(--border)';
      if (group) {
        const err = group.querySelector('.mc-form__error');
        if (err) err.style.display = 'none';
      }
    }, { once: true });
  }

  /* ══════════════════════════════════════════════
     20. FULL WIDTH BUTTON
     ══════════════════════════════════════════════ */
  function FullWidthBtn({ label, onClick, href, icon, variant = 'primary', loading: isLoading = false }) {
    const variants = {
      primary: { background: 'var(--hero-grad)', color: '#fff', border: 'none' },
      secondary: { background: 'var(--surface)', color: 'var(--text)', border: '1px solid var(--border)' },
      danger: { background: 'var(--red)', color: '#fff', border: 'none' },
      ghost: { background: 'transparent', color: 'var(--blue)', border: 'none', textDecoration: 'underline' },
    };
    const v = variants[variant] || variants.primary;

    const btn = el('button', {
      className: 'mc-btn-full',
      style: {
        width: '100%', padding: '14px', borderRadius: 'var(--r-lg)',
        ...v,
        fontSize: '16px', fontWeight: 600, cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
        position: 'relative', overflow: 'hidden',
        transition: 'transform 0.15s ease, opacity 0.15s ease',
        fontFamily: 'inherit',
      },
    });

    if (icon) btn.innerHTML = icon + ' ';
    btn.appendChild(document.createTextNode(label));

    // Ripple effect
    btn.addEventListener('click', (e) => {
      const ripple = el('span', {
        style: {
          position: 'absolute', borderRadius: '50%',
          background: 'rgba(255,255,255,0.3)',
          width: '20px', height: '20px',
          left: (e.offsetX - 10) + 'px', top: (e.offsetY - 10) + 'px',
          animation: 'asgardRipple 0.5s ease forwards',
          pointerEvents: 'none',
        },
      });
      btn.appendChild(ripple);
      setTimeout(() => ripple.remove(), 500);

      if (onClick) onClick();
      else if (href) Router.navigate(href);
    });

    btn.addEventListener('touchstart', () => btn.style.transform = 'scale(0.98)', { passive: true });
    btn.addEventListener('touchend', () => btn.style.transform = '', { passive: true });

    // Loading state — keeps gradient background
    btn.setLoading = (loading) => {
      if (loading) {
        btn._text = btn.innerHTML;
        btn._bg = btn.style.background;
        btn.innerHTML = '<div style="width:20px;height:20px;border:2px solid rgba(255,255,255,0.3);border-top-color:#fff;border-radius:50%;animation:asgardSpin 0.8s linear infinite"></div>';
        btn.disabled = true;
        btn.style.opacity = '0.85';
        // Force keep gradient — some browsers reset bg on disabled
        btn.style.setProperty('background', btn._bg, 'important');
      } else {
        btn.innerHTML = btn._text || label;
        btn.disabled = false;
        btn.style.opacity = '1';
        btn.style.setProperty('background', btn._bg || v.background);
      }
    };

    if (isLoading) btn.setLoading(true);

    return btn;
  }

  /* ══════════════════════════════════════════════
     21. DETAIL FIELDS
     ══════════════════════════════════════════════ */
  function DetailFields({ fields }) {
    const wrap = el('div', {
      className: 'mc-detail-fields',
      style: { display: 'flex', flexDirection: 'column', gap: '12px', padding: '0 var(--sp-page)' },
    });

    fields.forEach((f, i) => {
      const row = el('div', {
        style: {
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          paddingBottom: '12px', borderBottom: '1px solid var(--border)',
          ...DS.anim(i * 0.03),
        },
      });

      row.appendChild(el('div', {
        style: { ...DS.font('sm'), color: 'var(--text-sec)', flex: '0 0 auto', maxWidth: '40%' },
        textContent: f.label,
      }));

      const valWrap = el('div', { style: { display: 'flex', alignItems: 'center', gap: '6px', textAlign: 'right' } });

      if (f.type === 'badge') {
        valWrap.appendChild(Badge({ text: f.value, color: f.badgeColor || 'neutral' }));
      } else if (f.type === 'progress') {
        valWrap.appendChild(ProgressBar({ value: f.value, max: f.max || 100, label: f.value + '%' }));
      } else if (f.type === 'phone' || f.type === 'email') {
        const link = el('a', {
          style: { ...DS.font('base'), color: 'var(--blue)', fontWeight: 500, textDecoration: 'none' },
          href: f.type === 'phone' ? 'tel:' + f.value : 'mailto:' + f.value,
          textContent: f.value,
        });
        valWrap.appendChild(link);
      } else if (f.type === 'link') {
        const link = el('a', {
          style: { ...DS.font('base'), color: 'var(--blue)', fontWeight: 500, textDecoration: 'none', cursor: 'pointer' },
          textContent: f.value,
        });
        if (f.href) link.addEventListener('click', () => Router.navigate(f.href));
        valWrap.appendChild(link);
      } else {
        valWrap.appendChild(el('span', {
          style: { ...DS.font('base'), color: 'var(--text)', fontWeight: 500 },
          textContent: f.value || '—',
        }));
      }

      if (f.copy) {
        const copyBtn = el('button', {
          style: {
            background: 'var(--surface-alt)', border: '1px solid var(--border)', cursor: 'pointer',
            padding: '4px 6px', borderRadius: '6px',
            color: 'var(--text-sec)', fontSize: '16px', lineHeight: 1,
          },
          textContent: '📋',
          onClick: () => {
            navigator.clipboard.writeText(f.value).then(() => {
              Toast({ message: 'Скопировано', type: 'success', duration: 1500 });
            });
          },
        });
        valWrap.appendChild(copyBtn);
      }

      row.appendChild(valWrap);
      wrap.appendChild(row);
    });

    return wrap;
  }

  /* ══════════════════════════════════════════════
     22. PROGRESS BAR
     ══════════════════════════════════════════════ */
  function ProgressBar({ value, max = 100, color, label }) {
    const pct = Math.min(100, Math.max(0, (value / max) * 100));

    const wrap = el('div', {
      className: 'mc-progress',
      style: { display: 'flex', alignItems: 'center', gap: '8px', width: '100%' },
    });

    const track = el('div', {
      style: {
        flex: 1, height: '6px', borderRadius: '3px',
        background: 'var(--surface-alt)', overflow: 'hidden',
      },
    });

    const bar = el('div', {
      style: {
        height: '100%', borderRadius: '3px', width: '0%',
        background: color || (pct >= 75 ? 'var(--green)' : pct >= 50 ? 'var(--gold)' : pct >= 25 ? 'var(--orange)' : 'var(--red)'),
        transition: 'width 0.6s cubic-bezier(.34,1.56,.64,1)',
      },
    });
    track.appendChild(bar);
    wrap.appendChild(track);

    setTimeout(() => { bar.style.width = pct + '%'; }, 50);

    if (label) {
      wrap.appendChild(el('span', {
        style: { ...DS.font('xs'), color: 'var(--text-sec)', flexShrink: 0, minWidth: '30px', textAlign: 'right' },
        textContent: label,
      }));
    }

    return wrap;
  }

  /* ══════════════════════════════════════════════
     23. TABS (внутренние)
     ══════════════════════════════════════════════ */
  function Tabs({ items, active, onChange }) {
    const wrap = el('div', {
      className: 'mc-tabs asgard-no-scrollbar',
      style: {
        display: 'flex', overflowX: 'auto', borderBottom: '1px solid var(--border)',
        position: 'relative', scrollSnapType: 'x mandatory',
        width: '100%', maxWidth: '100vw',
        WebkitOverflowScrolling: 'touch',
      },
    });

    const indicator = el('div', {
      className: 'mc-tabs__indicator',
      style: {
        position: 'absolute', bottom: '-1px', height: '2px',
        background: 'var(--red)', borderRadius: '1px',
        transition: 'left 0.3s ease, width 0.3s ease',
      },
    });

    items.forEach((item, i) => {
      const tab = el('button', {
        className: 'mc-tab' + (item.value === active ? ' mc-tab--active' : ''),
        style: {
          padding: '10px 16px', background: 'none', border: 'none',
          ...DS.font('sm'),
          fontWeight: 600,
          color: item.value === active ? 'var(--text)' : 'var(--text-ter)',
          cursor: 'pointer', whiteSpace: 'nowrap', flexShrink: 0,
          transition: 'color 0.2s ease', scrollSnapAlign: 'start',
        },
        textContent: item.label,
        onClick: () => {
          active = item.value;
          wrap.querySelectorAll('.mc-tab').forEach((t, idx) => {
            const isActive = items[idx].value === active;
            t.className = 'mc-tab' + (isActive ? ' mc-tab--active' : '');
            t.style.color = isActive ? 'var(--text)' : 'var(--text-ter)';
          });
          updateIndicator();
          if (onChange) onChange(item.value);
        },
      });
      wrap.appendChild(tab);
    });

    wrap.appendChild(indicator);

    function updateIndicator() {
      const activeTab = wrap.querySelector('.mc-tab--active');
      if (activeTab) {
        indicator.style.left = activeTab.offsetLeft + 'px';
        indicator.style.width = activeTab.offsetWidth + 'px';
      }
    }

    setTimeout(updateIndicator, 0);
    return wrap;
  }

  /* ══════════════════════════════════════════════
     24. QUICK ACTIONS
     ══════════════════════════════════════════════ */
  function QuickActions({ items }) {
    const wrap = el('div', {
      className: 'mc-quick-actions asgard-no-scrollbar',
      style: {
        display: 'flex', gap: '8px', overflowX: 'auto', padding: '0 var(--sp-page)',
        scrollSnapType: 'x mandatory',
      },
    });

    items.forEach((item, i) => {
      const pill = el('button', {
        style: {
          display: 'flex', alignItems: 'center', gap: '6px',
          padding: '8px 14px', borderRadius: 'var(--r-md)',
          background: 'var(--surface-alt)', border: '1px solid var(--border)',
          color: 'var(--text)', cursor: 'pointer', whiteSpace: 'nowrap',
          ...DS.font('sm'), fontWeight: 600, flexShrink: 0,
          scrollSnapAlign: 'start',
          transition: 'background 0.2s ease, transform 0.15s ease',
          ...DS.anim(i * 0.05),
        },
        onClick: () => {
          if (item.onClick) item.onClick();
          else if (item.href) Router.navigate(item.href);
        },
      });

      if (item.icon) pill.appendChild(el('span', { textContent: item.icon }));
      pill.appendChild(el('span', { textContent: item.label }));

      pill.addEventListener('touchstart', () => pill.style.transform = 'scale(0.96)', { passive: true });
      pill.addEventListener('touchend', () => pill.style.transform = '', { passive: true });

      wrap.appendChild(pill);
    });

    return wrap;
  }

  /* ══════════════════════════════════════════════
     25. MIMIR BANNER
     ══════════════════════════════════════════════ */
  function MimirBanner({ title, text, icon = '⚡' }) {
    return el('div', {
      className: 'mc-mimir-banner',
      style: {
        background: 'var(--gold-bg)', border: '1px solid var(--gold-border)',
        borderRadius: 'var(--r-lg)', padding: '14px 16px',
        display: 'flex', gap: '12px', alignItems: 'flex-start',
        margin: '0 var(--sp-page)',
        ...DS.anim(0.1),
      },
    }, [
      el('span', { style: { fontSize: '20px', flexShrink: 0, lineHeight: 1 }, textContent: icon }),
      el('div', { style: { flex: 1 } }, [
        el('div', {
          style: { ...DS.font('sm'), fontWeight: 700, color: 'var(--gold)', marginBottom: '4px' },
          textContent: title || 'Мимир подсказывает',
        }),
        el('div', {
          style: { ...DS.font('sm'), color: 'var(--text-sec)', lineHeight: 1.4 },
          textContent: text,
        }),
      ]),
    ]);
  }

  /* ══════════════════════════════════════════════
     26. SEARCH BAR
     ══════════════════════════════════════════════ */
  function SearchBar({ placeholder = 'Поиск...', onSearch, sticky = false, autoFocus = false }) {
    const wrap = el('div', {
      className: 'mc-search',
      style: {
        padding: '8px var(--sp-page)',
        position: sticky ? 'sticky' : 'relative',
        top: sticky ? '0' : 'auto',
        zIndex: sticky ? 40 : 'auto',
        background: sticky ? 'var(--bg)' : 'transparent',
      },
    });

    const inner = el('div', {
      style: {
        display: 'flex', alignItems: 'center', gap: '8px',
        background: 'var(--surface-alt)', borderRadius: 'var(--r-md)',
        padding: '10px 14px', border: '1px solid var(--border)',
        transition: 'border-color 0.2s ease',
      },
    });

    inner.appendChild(el('span', {
      style: { color: 'var(--text-ter)', fontSize: '16px', flexShrink: 0, lineHeight: 1 },
      innerHTML: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>',
    }));

    const input = el('input', {
      type: 'search',
      placeholder,
      style: {
        flex: 1, background: 'none', border: 'none', outline: 'none',
        color: 'var(--text)', fontSize: '14px', fontFamily: 'inherit',
        padding: 0,
      },
    });

    const clearBtn = el('button', {
      style: {
        background: 'none', border: 'none', cursor: 'pointer', padding: '2px',
        color: 'var(--text-ter)', fontSize: '16px', display: 'none', lineHeight: 1,
      },
      textContent: '✕',
      onClick: () => {
        input.value = '';
        clearBtn.style.display = 'none';
        if (onSearch) onSearch('');
        input.focus();
      },
    });

    const debouncedSearch = Utils.debounce((q) => {
      if (onSearch) onSearch(q);
    }, 300);

    input.addEventListener('input', () => {
      clearBtn.style.display = input.value ? 'block' : 'none';
      debouncedSearch(input.value);
    });

    input.addEventListener('focus', () => { inner.style.borderColor = 'var(--blue)'; });
    input.addEventListener('blur', () => { inner.style.borderColor = 'var(--border)'; });

    inner.appendChild(input);
    inner.appendChild(clearBtn);
    wrap.appendChild(inner);

    if (autoFocus) setTimeout(() => input.focus(), 100);

    return wrap;
  }

  /* ══════════════════════════════════════════════
     PUBLIC API
     ══════════════════════════════════════════════ */
  return {
    Header,
    HeroCard,
    Card,
    Badge,
    FilterPills,
    Stats,
    Section,
    List,
    Empty,
    Skeleton,
    Toast,
    BottomSheet,
    Confirm,
    FAB,
    TablePage,
    BarChart,
    MiniChart,
    BigNumber,
    Form,
    FullWidthBtn,
    DetailFields,
    ProgressBar,
    Tabs,
    QuickActions,
    MimirBanner,
    SearchBar,
  };
})();

// Global export
if (typeof window !== 'undefined') {
  window.M = M;
}
