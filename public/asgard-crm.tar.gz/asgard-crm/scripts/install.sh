#!/bin/bash

# ═══════════════════════════════════════════════════════════════════════════
# ASGARD CRM - Server Installation Script
# ═══════════════════════════════════════════════════════════════════════════
# Usage: sudo bash install.sh
# ═══════════════════════════════════════════════════════════════════════════

set -e

echo "
╔═══════════════════════════════════════════════════════════════════════════╗
║                    ASGARD CRM - Installation                              ║
╚═══════════════════════════════════════════════════════════════════════════╝
"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo "❌ Please run as root: sudo bash install.sh"
  exit 1
fi

# ─────────────────────────────────────────────────────────────────────────────
# 1. Update system
# ─────────────────────────────────────────────────────────────────────────────
echo "📦 Updating system packages..."
apt update && apt upgrade -y

# ─────────────────────────────────────────────────────────────────────────────
# 2. Install dependencies
# ─────────────────────────────────────────────────────────────────────────────
echo "📦 Installing dependencies..."
apt install -y curl git nginx certbot python3-certbot-nginx

# ─────────────────────────────────────────────────────────────────────────────
# 3. Install Node.js 20
# ─────────────────────────────────────────────────────────────────────────────
echo "📦 Installing Node.js 20..."
if ! command -v node &> /dev/null; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt install -y nodejs
fi
echo "✅ Node.js $(node -v)"

# ─────────────────────────────────────────────────────────────────────────────
# 4. Install PostgreSQL
# ─────────────────────────────────────────────────────────────────────────────
echo "📦 Installing PostgreSQL..."
if ! command -v psql &> /dev/null; then
  apt install -y postgresql postgresql-contrib
  systemctl start postgresql
  systemctl enable postgresql
fi
echo "✅ PostgreSQL $(psql --version | cut -d' ' -f3)"

# ─────────────────────────────────────────────────────────────────────────────
# 5. Setup Database
# ─────────────────────────────────────────────────────────────────────────────
echo "🗄️ Setting up database..."

# Generate random password
DB_PASSWORD=$(openssl rand -base64 16 | tr -dc 'a-zA-Z0-9' | head -c 16)

# Create database and user
sudo -u postgres psql <<EOF
CREATE USER asgard WITH PASSWORD '$DB_PASSWORD';
CREATE DATABASE asgard_crm OWNER asgard;
GRANT ALL PRIVILEGES ON DATABASE asgard_crm TO asgard;
EOF

echo "✅ Database created"
echo "   User: asgard"
echo "   Password: $DB_PASSWORD"
echo "   Database: asgard_crm"

# ─────────────────────────────────────────────────────────────────────────────
# 6. Create app directory
# ─────────────────────────────────────────────────────────────────────────────
APP_DIR="/var/www/asgard-crm"
echo "📁 Creating app directory: $APP_DIR"
mkdir -p $APP_DIR
cd $APP_DIR

# ─────────────────────────────────────────────────────────────────────────────
# 7. Create .env file
# ─────────────────────────────────────────────────────────────────────────────
JWT_SECRET=$(openssl rand -base64 32)

cat > .env <<EOF
# ASGARD CRM Configuration
NODE_ENV=production
PORT=3000
HOST=0.0.0.0

# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=asgard_crm
DB_USER=asgard
DB_PASSWORD=$DB_PASSWORD

# JWT
JWT_SECRET=$JWT_SECRET
JWT_EXPIRES_IN=7d

# Telegram (fill in your bot token)
TELEGRAM_BOT_TOKEN=

# CORS
CORS_ORIGIN=*
EOF

echo "✅ .env file created"

# ─────────────────────────────────────────────────────────────────────────────
# 8. Setup systemd service
# ─────────────────────────────────────────────────────────────────────────────
echo "⚙️ Creating systemd service..."

cat > /etc/systemd/system/asgard-crm.service <<EOF
[Unit]
Description=ASGARD CRM API Server
After=network.target postgresql.service

[Service]
Type=simple
User=www-data
WorkingDirectory=$APP_DIR
ExecStart=/usr/bin/node src/index.js
Restart=on-failure
RestartSec=10
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=asgard-crm
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
echo "✅ Systemd service created"

# ─────────────────────────────────────────────────────────────────────────────
# 9. Setup Nginx
# ─────────────────────────────────────────────────────────────────────────────
echo "🌐 Configuring Nginx..."

cat > /etc/nginx/sites-available/asgard-crm <<EOF
server {
    listen 80;
    server_name _;

    root $APP_DIR/public;
    index index.html;

    # Gzip
    gzip on;
    gzip_types text/plain text/css application/json application/javascript;

    # API proxy
    location /api/ {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_cache_bypass \$http_upgrade;
    }

    # Static files
    location / {
        try_files \$uri \$uri/ /index.html;
    }

    # Security
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
}
EOF

ln -sf /etc/nginx/sites-available/asgard-crm /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

echo "✅ Nginx configured"

# ─────────────────────────────────────────────────────────────────────────────
# 10. Set permissions
# ─────────────────────────────────────────────────────────────────────────────
chown -R www-data:www-data $APP_DIR
chmod 600 $APP_DIR/.env

# ─────────────────────────────────────────────────────────────────────────────
# Done!
# ─────────────────────────────────────────────────────────────────────────────
echo "
╔═══════════════════════════════════════════════════════════════════════════╗
║                    ✅ Installation Complete!                              ║
╠═══════════════════════════════════════════════════════════════════════════╣
║                                                                           ║
║  Next steps:                                                              ║
║                                                                           ║
║  1. Copy server files to: $APP_DIR                                        ║
║     scp -r asgard-server/* root@your-server:$APP_DIR/                     ║
║                                                                           ║
║  2. Copy frontend files to: $APP_DIR/public                               ║
║     scp -r asgard-crm/* root@your-server:$APP_DIR/public/                 ║
║                                                                           ║
║  3. Install npm packages:                                                 ║
║     cd $APP_DIR && npm install --production                               ║
║                                                                           ║
║  4. Run migrations:                                                       ║
║     cd $APP_DIR && node migrations/run.js                                 ║
║                                                                           ║
║  5. Start the service:                                                    ║
║     systemctl start asgard-crm                                            ║
║     systemctl enable asgard-crm                                           ║
║                                                                           ║
║  6. (Optional) Setup SSL:                                                 ║
║     certbot --nginx -d your-domain.com                                    ║
║                                                                           ║
║  Database credentials saved in: $APP_DIR/.env                             ║
║                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝
"

echo "📝 Database password: $DB_PASSWORD"
echo "🔑 JWT secret: $JWT_SECRET"
